import requests
from bs4 import BeautifulSoup
import subprocess
import os
import re
import json
from time import sleep
from InquirerPy import prompt
from InquirerPy.validator import EmptyInputValidator
from InquirerPy.base.control import Choice
from InquirerPy.separator import Separator
from tqdm import tqdm

os.chdir(os.path.dirname(os.path.abspath(__file__)))

# --- CONFIGURAZIONE DATABASE ---
DB_FILE = "db.json"

def load_db():
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r") as f:
            return json.load(f)
    return {}

def save_db(data):
    with open(DB_FILE, "w") as f:
        json.dump(data, f, indent=4)

# --- SSL FIX ---
import urllib3
# Disabilita il warning "InsecureRequestWarning"
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
# Patcha requests.Session.request per aggiungere verify=False se non presente
_original_session_request = requests.Session.request
def _session_request_no_verify(self, method, url, *args, **kwargs):
    if 'verify' not in kwargs: kwargs['verify'] = False
    return _original_session_request(self, method, url, *args, **kwargs)
requests.Session.request = _session_request_no_verify

# --- VARIABILI GLOBALI ---
anime_scelto = ""
url_scelto = ""
ep_attuale = 0
max_ep = 0
stop_download = False

# --- UTILS ---
def path_giusto(titolo):
    # Rimuove caratteri illegali per le cartelle
    titolo = titolo.replace(":", " -")
    titolo = "".join(c for c in titolo if c.isalnum() or c in " .-_()[]")
    return titolo.strip()

def parse_metadata_anime(titolo_originale):
    """
    Estrae Nome, Stagione e Lingua.
    Return: (serie_name, season, lang)
    """
    # 1. Rileva la lingua
    lang = "ITA" if "(ITA)" in titolo_originale else "SUB"
    
    # 2. Pulisci il titolo dai tag per l'elaborazione successiva
    titolo_clean = titolo_originale.replace("(ITA)", "").strip()
    
    # 3. Logica esistente per la stagione
    season = 1
    serie_name = titolo_clean

    match_season = re.search(r"(?:Season\s+(\d+)|(\d+)(?:st|nd|rd|th)?\s+Season)", titolo_clean, re.IGNORECASE)
    
    if match_season:
        season = int(match_season.group(1) or match_season.group(2))
        serie_name = re.sub(r"(?:Season\s+(\d+)|(\d+)(?:st|nd|rd|th)?\s+Season|:)", "", titolo_clean, flags=re.IGNORECASE).strip()
    else:
        match_num = re.search(r"\s(\d+)$", titolo_clean)
        if match_num:
            season = int(match_num.group(1))
            serie_name = titolo_clean[:match_num.start()].strip()
    
    return serie_name, season, lang

# --- SCRAPING ---
def cerca_nome(query):
    url = f"https://www.animeworld.ac/search?keyword={query}"
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        # Modifica il selettore in base alla struttura della pagina
        titoli = soup.find_all("a", class_="name")
        fatto = {}
        for titolo in titoli:
            fatto[titolo.text.strip()] = titolo['href']
        return fatto if fatto else False
    return False

def cerca_ep(url):
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        # Naviga la struttura in modo più robusto
        server = soup.find("div", class_="server active")
        episodi = {}
        if server:
            ul_list = server.find_all("ul", class_="episodes range active")
            for ul in ul_list:
                for li in ul.find_all("li"):
                    a = li.find("a")
                    if a and a.text.strip():
                        episodi[a.text.strip()] = a['href']
        return episodi
    else:
        print("Errore nella richiesta")

def get_real_video_url(url):
    global stop_download
    stop_download = False

    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        url = soup.find("a", class_="m-1 btn btn-sm btn-primary")['href']
        # print(f"URL down video trovato: {url}")
    else:
        print("Errore nella richiesta")
        return

    url_prima_parte = url.split("/download-file.php")[0]
    # print (f"URL prima parte: {url_prima_parte}")
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        url = url_prima_parte + soup.find("a", class_="w-100 btn btn-lg btn-primary mt-2 mb-2")['href'][2:]
        # print(f"URL video trovato: {url}")
    else:
        print("Errore nella richiesta")
        return
    if url:
        return url

# --- CORE FUNCTIONS ---

def carica(ep, url):
    url = get_real_video_url(url)
    try:
        proc = subprocess.Popen(f'mpv --save-position-on-quit "{url}"', shell=True)
    except:
        proc = subprocess.Popen(f'mpv/mpv.exe --save-position-on-quit "{url}"', shell=True)

    sleep(2)  # Attendi un momento per assicurarti che mpv sia avviato
    proc.wait()

def url_jelly(episodi_dict, anime_url, anime_scelto_=False):
    """
    Gestisce il salvataggio strutturato per Jellyfin e aggiorna il DB locale.
    """
    db = load_db()
    titolo_completo = anime_scelto_ if anime_scelto_ else anime_scelto
    titolo_completo = path_giusto(titolo_completo)

    # 1. Indovina i metadati
    guess_serie, guess_season, guess_lang = parse_metadata_anime(titolo_completo)
    print(f"\nConfigurazione salvataggio per: {titolo_completo}")

    if guess_lang == "ITA":
        guess_serie = f"{guess_serie} (ITA)"

    # 2. Chiedi conferma all'utente (InquirerPy)
    q_meta = [
        {"type": "input", "message": "Nome Serie (Cartella Principale):", "name": "serie", "default": guess_serie},
        {"type": "input", "message": "Numero Stagione:", "name": "season", "default": str(guess_season), "validate": lambda x: x.isdigit(), "filter": lambda x: int(x)},
        {"type": "list", "message": "Stato Anime:", "name": "status", "choices": ["In Corso", "Concluso"]}
    ]
    meta = prompt(q_meta)

    serie_path = path_giusto(meta['serie'])
    season_path = f"Season {meta['season']:02d}"
    full_path = os.path.join("down", serie_path, season_path)

    os.makedirs(full_path, exist_ok=True)

    # 3. Salva nel DB
    db_key = f"{serie_path}_S{meta['season']}"
    db[db_key] = {
        "serie_name": meta['serie'],
        "season": meta['season'],
        "url": anime_url,
        "status": "ongoing" if meta['status'] == "In Corso" else "finished",
        "folder": full_path,
        "last_ep_downloaded": []
    }

    # 4. Scarica i file .strm
    print(f"\nSalvataggio collegamenti in: {full_path}")
    progress = tqdm(total=len(episodi_dict), desc="Creazione .strm", unit="ep")
    
    nuovi_ep = []
    
    for ep_num, link in episodi_dict.items():
        filename = f"E{ep_num}.strm" if ep_num.isdigit() else f"{ep_num}.strm"
        filepath = os.path.join(full_path, filename)
        
        # Evita di rifare richieste se il file esiste
        if not os.path.exists(filepath):
            real_url = get_real_video_url(f"https://www.animeworld.ac{link}")
            if real_url:
                with open(filepath, "w") as f:
                    f.write(real_url)
                nuovi_ep.append(ep_num)
        
        progress.update(1)
    
    progress.close()
    
    # Aggiorna lista episodi nel db
    # Uniamo quelli vecchi con quelli appena scaricati per non perdere lo storico
    existing_eps = set(db[db_key].get("last_ep_downloaded", []))
    existing_eps.update(nuovi_ep)
    db[db_key]["last_ep_downloaded"] = list(existing_eps)
    
    save_db(db)
    print("✅ Salvataggio completato e Database aggiornato.")
    sleep(1)

def aggiorna_libreria():
    """
    Scansiona il DB locale e controlla nuovi episodi solo per le serie 'ongoing'.
    """
    db = load_db()
    ongoing_series = {k: v for k, v in db.items() if v.get("status") == "ongoing"}
    
    if not ongoing_series:
        print("Nessuna serie 'In Corso' trovata nel database.")
        sleep(2)
        return

    print(f"Controllo aggiornamenti per {len(ongoing_series)} serie...")
    
    count_new = 0
    
    for key, data in ongoing_series.items():
        print(f"Checking: {data['serie_name']} (Season {data['season']})...")
        episodi_online = cerca_ep(data['url'])

        path_dest = data['folder']
        os.makedirs(path_dest, exist_ok=True)
        
        downloaded = set(data['last_ep_downloaded'])
        
        for ep_num, link in episodi_online.items():
            # Controllo brutale: se non l'abbiamo nella lista o il file non c'è
            filename = f"E{ep_num}.strm" if ep_num.isdigit() else f"{ep_num}.strm"
            filepath = os.path.join(path_dest, filename)
            
            if ep_num not in downloaded or not os.path.exists(filepath):
                print(f" -> Nuovo episodio trovato: {ep_num}")
                real_url = get_real_video_url(f"https://www.animeworld.ac{link}")
                if real_url:
                    with open(filepath, "w") as f:
                        f.write(real_url)
                    db[key]["last_ep_downloaded"].append(ep_num)
                    count_new += 1
    
    save_db(db)
    print(f"\n✅ Aggiornamento completato. {count_new} nuovi episodi aggiunti.")
    input("Premi invio per tornare al menu...")

# --- MENU FUNCTIONS ---

def scegli_anime():
    os.system('cls' if os.name == 'nt' else 'clear')
    global anime_scelto, url_scelto
    try:
        questions = [
            {
                "type": "input",
                "message": "Cerca un anime:",
                "name": "query",
                "validate": EmptyInputValidator(),
            }
        ]
        query_result = prompt(questions)
        if not query_result: return False

        risultati = cerca_nome(query_result["query"])
        if not risultati:
            print("Nessun risultato trovato.")
            return False

        anime_choices = [Choice(value=link, name=titolo) for titolo, link in risultati.items()]
        questions = [
            {
                "type": "list",
                "message": "Seleziona un anime:",
                "choices": anime_choices,
                "name": "anime_selection",
            }
        ]
        selection_result = prompt(questions)
        if not selection_result: return False
        
        url_scelto = f"https://www.animeworld.ac{selection_result['anime_selection']}"
        # Find the key (anime title) corresponding to the selected value (link)
        anime_scelto = next(key for key, value in risultati.items() if value == selection_result['anime_selection'])
        print(f"Hai scelto: {anime_scelto}")
        return True

    except KeyboardInterrupt:
        return False

def scegli_ep(next_ep=False, ricarica=False):
    global ep_attuale, max_ep
    os.system('cls')
    episodi = cerca_ep(url_scelto)
    if not episodi:
        print("Nessun episodio trovato.")
        return

    max_ep = len(episodi)
    
    if next_ep:
        ep_attuale += 1
    elif ricarica:
        pass
    else:
        ep_choices = []
        ep_choices.append(Choice(value="jelly", name=f"▶️  Aggiungi a Jellyfin"))
        ep_choices += [Choice(value=link, name=f"Episodio {i+1}: {nome}") for i, (nome, link) in enumerate(episodi.items())]
        questions = [
            {
                "type": "list",
                "message": f"Scegli un episodio di {anime_scelto}:",
                "choices": ep_choices,
                "name": "episode_selection",
                "cycle": False,
            }
        ]
        try:
            selection_result = prompt(questions)
            if not selection_result: return
            if selection_result['episode_selection'] == "jelly":
                url_jelly(episodi, url_scelto)
                return True

            # Find the index of the chosen episode
            selected_link = selection_result['episode_selection']
            ep_attuale = list(episodi.values()).index(selected_link)

        except KeyboardInterrupt:
            return

    episodio_nome = list(episodi.keys())[ep_attuale]
    url_ep_scelto = f"https://www.animeworld.ac{episodi[episodio_nome]}"
    carica(episodio_nome, url_ep_scelto)

def carica_preferiti():
    global anime_scelto, url_scelto
    if os.path.exists("preferiti.txt"):
        with open("preferiti.txt", "r") as f:
            preferiti = {}
            for line in f:
                if " - " in line:
                    nome, link = line.strip().split(" - ", 1)
                    preferiti[nome] = link
        return preferiti
    else:
        print("Nessun preferito trovato.")
        return {}

def salva_preferito():
    global anime_scelto, url_scelto
    with open("preferiti.txt", "a") as f:
        f.write(f"{anime_scelto} - {url_scelto}\n")
    print(f"Anime '{anime_scelto}' salvato nei preferiti.")

def rimuovi_preferito():
    preferiti = carica_preferiti()
    if not preferiti:
        print("Nessun preferito da rimuovere.")
        sleep(2)
        return

    try:
        pref_choices = [Choice(value=link, name=nome) for nome, link in preferiti.items()]
        questions = [
            {
                "type": "list",
                "message": "Seleziona un anime da rimuovere:",
                "choices": pref_choices,
                "name": "anime_da_rimuovere",
            }
        ]
        selection_result = prompt(questions)
        if not selection_result: return
        
        nome_da_rimuovere = next(key for key, value in preferiti.items() if value == selection_result['anime_da_rimuovere'])
        del preferiti[nome_da_rimuovere]

        with open("preferiti.txt", "w") as f:
            for nome, link in preferiti.items():
                f.write(f"{nome} - {link}\n")
        print(f"'{nome_da_rimuovere}' rimosso dai preferiti.")
        sleep(2)

    except KeyboardInterrupt:
        return

def menu_post_visione():
    os.system('cls')
    global stop_download
    while True:
        preferiti = carica_preferiti()
        choices = []

        if ep_attuale < max_ep - 1:
            choices.append(Choice(value="prossimo", name=f"▶️  Prossimo episodio ({ep_attuale + 2})"))
        else:
            choices.append(Choice(value=None, name="⏹️  Non ci sono altri episodi"))

        choices.extend([
            Choice(value="scegli", name="🔢 Scegli un altro episodio"),
            Choice(value="ricarica", name="🔃 Ricarica"),
            Separator(),
        ])

        if anime_scelto not in preferiti:
            choices.append(Choice(value="salva", name="⭐ Salva anime nei preferiti"))
        
        choices.append(Choice(value="esci", name="🚪 Esci"))

        questions = [{
            "type": "list",
            "message": "Cosa vuoi fare ora?",
            "choices": choices,
            "name": "scelta_finale"
        }]

        try:
            result = prompt(questions)
            if not result: # Handle Ctrl+C
                stop_download = True
                print("\nUscita dal programma.")
                break
            
            scelta = result['scelta_finale']

            if scelta == "prossimo":
                stop_download = True
                scegli_ep(next_ep=True)
            elif scelta == "scegli":
                stop_download = True
                scegli_ep()
            elif scelta == "ricarica":
                scegli_ep(ricarica=True)
            elif scelta == "salva":
                salva_preferito()
            elif scelta == "esci":
                stop_download = True
                print("\nUscita dal programma.")
                break
        except KeyboardInterrupt:
            stop_download = True
            print("\nUscita dal programma.")
            break

def cerca_upt(percorso_base = "./down"):
    def get_episodi_presenti(nome_path):
        file_validi = [f for f in os.listdir(f"{percorso_base}/{nome_path}") if f.lower().endswith(('.strm', '.mp4'))]
        # Salva il tipo dal primo elemento (se esiste)
        tipo_file = os.path.splitext(file_validi[0])[1].replace('.', '') if file_validi else None
        # Salva i nomi puliti
        nomi_puliti = [os.path.splitext(f)[0].replace("E", "") for f in file_validi]
        return nomi_puliti
    tutti = [nome for nome in os.listdir(percorso_base) if os.path.isdir(os.path.join(percorso_base, nome))]

    mancanti = {}
    for nome_path in tutti:
        print("Controllo:", nome_path)
        nome, url_ani = next(iter(cerca_nome(nome_path.replace(" - ", ": ")).items()))
        url_ani = f"https://www.animeworld.ac{url_ani}"
        episodi = cerca_ep(url_ani)
        episodi_presenti = get_episodi_presenti(nome_path)
        for nome_ep, url in episodi.items():
            if nome_ep in episodi_presenti: continue
            else:
                if nome not in mancanti: mancanti[nome] = []  # Crea la lista per questa serie
                mancanti[nome].append((nome_ep, f"https://www.animeworld.ac{url}"))
    return mancanti


def main():
    global anime_scelto, url_scelto
    
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("Benvenuto in Ani-CLI-ITA!")

        preferiti = carica_preferiti()

        choices = [
            Choice("cerca", "🔍 Cerca un nuovo anime"),
            Choice("aggiorna", "🔄 Aggiorna Libreria (Check Nuovi Episodi)"),
            Choice("rimuovi", "🗑️  Rimuovi un anime dai preferiti")
        ]
        
        if preferiti:
            choices.append(Separator("--- PREFERITI ---"))
            pref_choices = [Choice(value=link, name=nome) for nome, link in preferiti.items()]
            choices.extend(pref_choices)

        questions = [
            {
                "type": "list",
                "message": "Scegli un'opzione:",
                "choices": choices,
                "name": "scelta_iniziale"
            }
        ]

        try:
            result = prompt(questions)
            if not result: break # Exit on Ctrl+C
            
            scelta = result['scelta_iniziale']

            if scelta == "cerca":
                if scegli_anime():
                    if scegli_ep():
                        return
                    menu_post_visione()
            elif scelta == "rimuovi":
                rimuovi_preferito()
            elif scelta == "aggiorna":
                aggiorna_libreria()
            else: # An anime from favorites was selected
                url_scelto = scelta
                anime_scelto = next(key for key, value in preferiti.items() if value == scelta)
                print(f"Hai scelto: {anime_scelto}")
                scegli_ep()
                menu_post_visione()

        except KeyboardInterrupt:
            print("\nUscita dal programma.")
            break

if __name__ == "__main__":
    main()
    # cerca_upt()