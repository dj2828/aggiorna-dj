import requests
from bs4 import BeautifulSoup
import subprocess
import os
import threading
from time import sleep
from InquirerPy import prompt
from InquirerPy.validator import EmptyInputValidator
from InquirerPy.base.control import Choice
from InquirerPy.separator import Separator
from tqdm import tqdm

os.chdir(os.path.dirname(os.path.abspath(__file__)))

# PER LA GESTIONE DEI CERTIFICATI SSL NON VALIDATI
import urllib3
# Disabilita il warning "InsecureRequestWarning"
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
# Patcha requests.Session.request per aggiungere verify=False se non presente
_original_session_request = requests.Session.request
def _session_request_no_verify(self, method, url, *args, **kwargs):
    if 'verify' not in kwargs:
        kwargs['verify'] = False
    return _original_session_request(self, method, url, *args, **kwargs)
requests.Session.request = _session_request_no_verify

anime_scelto = ""
url_scelto = ""
ep_attuale = 0
max_ep = 0

stop_download = False

def path_giusto(titolo):
    titolo = titolo.replace(":", " -")
    titolo = "".join(c for c in titolo if c.isalnum() or c in " .-_()[]")
    titolo = titolo.strip()
    return titolo

def cerca_nome(query):
    url = f"https://www.animeworld.ac/search?keyword={query}"
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        # Modifica il selettore in base alla struttura della pagina
        titoli = soup.find_all("a", class_="name")
        fatto = {}
        for titolo in titoli:
            fatto[titolo.text.strip()] = titolo['href']
        if not fatto:
            print("Nessun risultato trovato.")
            return False
        return fatto
    else:
        print("Errore nella richiesta")

def cerca_ep(url):
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        # Naviga la struttura in modo più robusto
        server = soup.find("div", class_="server active")
        episodi = {}
        if server:
            ul_list = server.find_all("ul", class_="episodes range active")
            for ul in ul_list:
                for li in ul.find_all("li"):
                    a = li.find("a")
                    if a and a.text.strip():
                        episodi[a.text.strip()] = a['href']
        return episodi
    else:
        print("Errore nella richiesta")

def get_real_video_url(url):
    global stop_download
    stop_download = False

    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        url = soup.find("a", class_="m-1 btn btn-sm btn-primary")['href']
        # print(f"URL down video trovato: {url}")
    else:
        print("Errore nella richiesta")
        return

    url_prima_parte = url.split("/download-file.php")[0]
    # print (f"URL prima parte: {url_prima_parte}")
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        url = url_prima_parte + soup.find("a", class_="w-100 btn btn-lg btn-primary mt-2 mb-2")['href'][2:]
        # print(f"URL video trovato: {url}")
    else:
        print("Errore nella richiesta")
        return
    if url:
        return url

def scarica_anime(ep, url):
    titolo = path_giusto(anime_scelto)
    url = get_real_video_url(url)
    file_mp4 = f"down/{titolo}/{ep}.mp4"
    file_part = f"down/{titolo}/{ep}.mp4.part"

    # Crea la cartella se non esiste
    os.makedirs(os.path.dirname(file_mp4), exist_ok=True)

    if not os.path.exists(file_mp4):
        resume_byte_pos = 0
        headers = {}

        # Se esiste un file parziale, riprende da dove era rimasto
        if os.path.exists(file_part):
            resume_byte_pos = os.path.getsize(file_part)
            headers['Range'] = f'bytes={resume_byte_pos}-'

        # Richiesta HTTP con supporto resume
        with requests.get(url, headers=headers, stream=True) as r:
            r.raise_for_status()

            # Calcola la dimensione totale da scaricare
            total_size = int(r.headers.get('content-length', 0)) + resume_byte_pos

            # Barra di avanzamento (in byte)
            progress = tqdm(
                total=total_size,
                initial=resume_byte_pos,
                desc=f"Download episodio {ep}",
                unit="B",
                unit_scale=True,
                ncols=80
            )

            with open(file_part, 'ab') as video_file:
                for chunk in r.iter_content(chunk_size=8192):
                    if chunk:
                        video_file.write(chunk)
                        progress.update(len(chunk))

            progress.close()

        # Rinomina il file quando finito
        os.rename(file_part, file_mp4)
        tqdm.write(f"\n✅ Download completato: {file_mp4}")
    else:
        tqdm.write(f"✅ Episodio {ep} già scaricato.")


def url_jelly(ep, url, anime_scelto_=False):
    titolo = anime_scelto_ if anime_scelto_ else anime_scelto
    titolo = path_giusto(titolo)
    if os.path.exists(f"down/{titolo}/E{ep}.mp4"):
        print("Anime gia scaricato")
        sleep(1)
        return 1
    elif os.path.exists(f"down/{titolo}/E{ep}.strm"):
        print(f"{ep} esiste gia")
        return 0
    os.makedirs(os.path.dirname(f"down/{titolo}/E{ep}.strm"), exist_ok=True)
    url = get_real_video_url(url)
    with open(f"down/{titolo}/E{ep}.strm", "w") as f:
        f.write(url)


def carica(ep, url):
    url = get_real_video_url(url)

# QUELLO CHE SEGUE IN COMMENTO E' IL CODICE PER SCARICARE IL VIDEO 

    # os.makedirs(anime_scelto, exist_ok=True)
    # file_mp4 = f"{anime_scelto}/{ep}.mp4"
    # file_part = f"{anime_scelto}/{ep}.mp4.part"

    # if not os.path.exists(file_part) or not os.path.exists(file_mp4):
    #     print("Scarico i primi MB per iniziare la visione...")
    #     with requests.get(url, stream=True) as r:
    #         with open(file_part, 'wb') as f:
    #             for i, chunk in enumerate(r.iter_content(chunk_size=8192)):
    #                 if i > 1200:  # circa 10 MB
    #                     break
    #                 f.write(chunk)
    #     print("Download iniziale completato, avvio MPV...")

    # def scarica_video():
    #     global stop_download
    #     resume_byte_pos = 0
    #     if os.path.exists(file_part):
    #         resume_byte_pos = os.path.getsize(file_part)

    #     headers = {}
    #     if resume_byte_pos > 0:
    #         headers['Range'] = f'bytes={resume_byte_pos}-'

    #     with open(file_part, 'ab') as video_file:
    #         with requests.get(url, headers=headers, stream=True) as r:
    #             r.raise_for_status()
    #             for i, chunk in enumerate(r.iter_content(chunk_size=8192)):
    #                 if stop_download:
    #                     print("Download interrotto.")
    #                     return
    #                 video_file.write(chunk)
    #     if not stop_download:
    #         os.rename(file_part, file_mp4)
    #         print(f"\nDownload completato. Video salvato in: {file_mp4}")

    # # Se il file completo non esiste, avvia il download in background
    # t = None
    # if not os.path.exists(file_mp4):
    #     print("Download in corso... Puoi già aprire il video con MPV.")
        # t = threading.Thread(target=scarica_video)
        # t.start()
        # mpv_file = file_part
    # else:
    #     mpv_file = file_mp4

    # mpv_file = url

# FINE SCARICA
    if os.path.exists(f"down/{path_giusto(anime_scelto)}/{ep}.mp4"):
        mpv_file = f"down/{path_giusto(anime_scelto)}/{ep}.mp4"
        print(f"Avvio mpv con il file scaricato: {mpv_file}")
    else:
        mpv_file = url
    # Avvia mpv subito (sia su .part che su .mp4)

    # print(f"Avvio mpv con il file: {mpv_file}")
    sleep(1)
    try:
        proc = subprocess.Popen(f'mpv --save-position-on-quit "{mpv_file}"', shell=True)
    except:
        proc = subprocess.Popen(f'mpv/mpv.exe --save-position-on-quit "{mpv_file}"', shell=True)

    sleep(2)  # Attendi un momento per assicurarti che mpv sia avviato
    proc.wait()

    # ALTRA ROBA SCARICA
        # stop_download = True
        # if t:
        #     t.join()

def scegli_anime():
    os.system('cls')
    global anime_scelto, url_scelto
    try:
        questions = [
            {
                "type": "input",
                "message": "Cerca un anime:",
                "name": "query",
                "validate": EmptyInputValidator(),
            }
        ]
        query_result = prompt(questions)
        if not query_result: return False

        risultati = cerca_nome(query_result["query"])
        if not risultati:
            print("Nessun risultato trovato.")
            return False

        anime_choices = [Choice(value=link, name=titolo) for titolo, link in risultati.items()]
        questions = [
            {
                "type": "list",
                "message": "Seleziona un anime:",
                "choices": anime_choices,
                "name": "anime_selection",
            }
        ]
        selection_result = prompt(questions)
        if not selection_result: return False
        
        url_scelto = f"https://www.animeworld.ac{selection_result['anime_selection']}"
        # Find the key (anime title) corresponding to the selected value (link)
        anime_scelto = next(key for key, value in risultati.items() if value == selection_result['anime_selection'])
        print(f"Hai scelto: {anime_scelto}")
        return True

    except KeyboardInterrupt:
        return False

def scegli_ep(next_ep=False, ricarica=False):
    global ep_attuale, max_ep
    os.system('cls')
    episodi = cerca_ep(url_scelto)
    if not episodi:
        print("Nessun episodio trovato.")
        return

    max_ep = len(episodi)
    
    if next_ep:
        ep_attuale += 1
    elif ricarica:
        pass
    else:
        ep_choices = []
        ep_choices.append(Choice(value="jelly", name=f"▶️  Aggiungi a Jellyfin"))
        ep_choices.append(Choice(value="scarica", name=f"▶️  Scarica anime"))
        ep_choices += [Choice(value=link, name=f"Episodio {i+1}: {nome}") for i, (nome, link) in enumerate(episodi.items())]
        questions = [
            {
                "type": "list",
                "message": f"Scegli un episodio di {anime_scelto}:",
                "choices": ep_choices,
                "name": "episode_selection",
                "cycle": False,
            }
        ]
        try:
            selection_result = prompt(questions)
            if not selection_result: return
            if selection_result['episode_selection'] == "scarica":
                progress = tqdm(total=len(episodi), desc="Download anime", unit="episodio")
                for episode, link in episodi.items():
                    scarica_anime(episode, f"https://www.animeworld.ac{link}")
                    progress.update(1)
                progress.close()
                return True
            if selection_result['episode_selection'] == "jelly":
                progress = tqdm(total=len(episodi), desc="Download anime", unit="episodio")
                for episode, link in episodi.items():
                    if url_jelly(episode, f"https://www.animeworld.ac{link}") == 1:
                        break
                    progress.update(1)
                progress.close()
                return True

            # Find the index of the chosen episode
            selected_link = selection_result['episode_selection']
            ep_attuale = list(episodi.values()).index(selected_link)

        except KeyboardInterrupt:
            return

    episodio_nome = list(episodi.keys())[ep_attuale]
    url_ep_scelto = f"https://www.animeworld.ac{episodi[episodio_nome]}"
    carica(episodio_nome, url_ep_scelto)

def carica_preferiti():
    global anime_scelto, url_scelto
    if os.path.exists("preferiti.txt"):
        with open("preferiti.txt", "r") as f:
            preferiti = {}
            for line in f:
                if " - " in line:
                    nome, link = line.strip().split(" - ", 1)
                    preferiti[nome] = link
        return preferiti
    else:
        print("Nessun preferito trovato.")
        return {}

def salva_preferito():
    global anime_scelto, url_scelto
    with open("preferiti.txt", "a") as f:
        f.write(f"{anime_scelto} - {url_scelto}\n")
    print(f"Anime '{anime_scelto}' salvato nei preferiti.")

def rimuovi_preferito():
    preferiti = carica_preferiti()
    if not preferiti:
        print("Nessun preferito da rimuovere.")
        sleep(2)
        return

    try:
        pref_choices = [Choice(value=link, name=nome) for nome, link in preferiti.items()]
        questions = [
            {
                "type": "list",
                "message": "Seleziona un anime da rimuovere:",
                "choices": pref_choices,
                "name": "anime_da_rimuovere",
            }
        ]
        selection_result = prompt(questions)
        if not selection_result: return
        
        nome_da_rimuovere = next(key for key, value in preferiti.items() if value == selection_result['anime_da_rimuovere'])
        del preferiti[nome_da_rimuovere]

        with open("preferiti.txt", "w") as f:
            for nome, link in preferiti.items():
                f.write(f"{nome} - {link}\n")
        print(f"'{nome_da_rimuovere}' rimosso dai preferiti.")
        sleep(2)

    except KeyboardInterrupt:
        return

def menu_post_visione():
    os.system('cls')
    global stop_download
    while True:
        preferiti = carica_preferiti()
        choices = []

        if ep_attuale < max_ep - 1:
            choices.append(Choice(value="prossimo", name=f"▶️  Prossimo episodio ({ep_attuale + 2})"))
        else:
            choices.append(Choice(value=None, name="⏹️  Non ci sono altri episodi"))

        choices.extend([
            Choice(value="scegli", name="🔢 Scegli un altro episodio"),
            Choice(value="ricarica", name="🔃 Ricarica"),
            Separator(),
        ])

        if anime_scelto not in preferiti:
            choices.append(Choice(value="salva", name="⭐ Salva anime nei preferiti"))
        
        choices.append(Choice(value="esci", name="🚪 Esci"))

        questions = [{
            "type": "list",
            "message": "Cosa vuoi fare ora?",
            "choices": choices,
            "name": "scelta_finale"
        }]

        try:
            result = prompt(questions)
            if not result: # Handle Ctrl+C
                stop_download = True
                print("\nUscita dal programma.")
                break
            
            scelta = result['scelta_finale']

            if scelta == "prossimo":
                stop_download = True
                scegli_ep(next_ep=True)
            elif scelta == "scegli":
                stop_download = True
                scegli_ep()
            elif scelta == "ricarica":
                scegli_ep(ricarica=True)
            elif scelta == "salva":
                salva_preferito()
            elif scelta == "esci":
                stop_download = True
                print("\nUscita dal programma.")
                break
        except KeyboardInterrupt:
            stop_download = True
            print("\nUscita dal programma.")
            break

def cerca_upt(percorso_base = "./down"):
    def get_episodi_presenti(nome_path):
        file_validi = [f for f in os.listdir(f"{percorso_base}/{nome_path}") if f.lower().endswith(('.strm', '.mp4'))]
        # Salva il tipo dal primo elemento (se esiste)
        tipo_file = os.path.splitext(file_validi[0])[1].replace('.', '') if file_validi else None
        # Salva i nomi puliti
        nomi_puliti = [os.path.splitext(f)[0].replace("E", "") for f in file_validi]
        return nomi_puliti
    tutti = [nome for nome in os.listdir(percorso_base) if os.path.isdir(os.path.join(percorso_base, nome))]

    mancanti = {}
    for nome_path in tutti:
        print("Controllo:", nome_path)
        nome, url_ani = next(iter(cerca_nome(nome_path.replace(" - ", ": ")).items()))
        url_ani = f"https://www.animeworld.ac{url_ani}"
        episodi = cerca_ep(url_ani)
        episodi_presenti = get_episodi_presenti(nome_path)
        for nome_ep, url in episodi.items():
            if nome_ep in episodi_presenti: continue
            else:
                if nome not in mancanti: mancanti[nome] = []  # Crea la lista per questa serie
                mancanti[nome].append((nome_ep, f"https://www.animeworld.ac{url}"))
    return mancanti


def main():
    global anime_scelto, url_scelto
    
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("Benvenuto in Ani-CLI-ITA!")

        preferiti = carica_preferiti()

        choices = [
            Choice("cerca", "🔍 Cerca un nuovo anime"),
            Choice("aggiorna", "🔁 Cerca nuovi episodi degli anime scaricati"),
            Choice("rimuovi", "🗑️  Rimuovi un anime dai preferiti")
        ]
        
        if preferiti:
            choices.append(Separator("--- PREFERITI ---"))
            pref_choices = [Choice(value=link, name=nome) for nome, link in preferiti.items()]
            choices.extend(pref_choices)

        questions = [
            {
                "type": "list",
                "message": "Scegli un'opzione:",
                "choices": choices,
                "name": "scelta_iniziale"
            }
        ]

        try:
            result = prompt(questions)
            if not result: break # Exit on Ctrl+C
            
            scelta = result['scelta_iniziale']

            if scelta == "cerca":
                if scegli_anime():
                    if scegli_ep():
                        return
                    menu_post_visione()
            elif scelta == "rimuovi":
                rimuovi_preferito()
            elif scelta == "aggiorna":
                mancanti = cerca_upt()
                try: os.system("cls")
                except: os.system("clear")
                if not mancanti:
                    print("✅ Non ci sono nuovi episodi da scaricare.")
                else:
                    print("✅ Scaricati")
                    for serie, episodi in mancanti.items():
                        anime_scelto = serie
                        print(f"--- SERIE: {serie} ---")
                        for ep, url in episodi:
                            print(f"Episodio {ep}: {url}")
                            url_jelly(ep, url)
                input("\nPremi invio")
            else: # An anime from favorites was selected
                url_scelto = scelta
                anime_scelto = next(key for key, value in preferiti.items() if value == scelta)
                print(f"Hai scelto: {anime_scelto}")
                scegli_ep()
                menu_post_visione()

        except KeyboardInterrupt:
            print("\nUscita dal programma.")
            break

if __name__ == "__main__":
    main()
    # cerca_upt()