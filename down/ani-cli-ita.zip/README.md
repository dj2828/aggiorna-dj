# ani-cli-ita

fai "py -m pip install -r requirements.txt" in un terminale

compatibile con jellyfin. mettere nella libreria jellyfin la cartella "down/"