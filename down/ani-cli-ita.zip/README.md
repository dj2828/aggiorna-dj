# ani-cli-ita

scarica questo e mettilo nella stessa cartella di "main.py" (devi rinominare la cartella estratta dallo .zip in "mpv")
https://nightly.link/mpv-player/mpv/workflows/build/master/mpv-x86_64-pc-windows-msvc.zip

fai "py -m pip install -r requirements.txt" in un terminale