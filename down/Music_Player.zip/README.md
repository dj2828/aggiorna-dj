
# Music Player

## Config.txt
Crea `config.txt` nella root

In config ci sono 3 tipi di config

`{Nome cartella che vuoi che di legga}={Path cartella}`
Es: `Tha Supreme=X:\canz\thasup`

NON CANCELLATE `YouTube=MUSIC_FOLDER`

`#{Indirizzo IP locale}` Es: `#192.168.1.8`

`ALBUM_ORDER={Ordine album}` Es: `ALBUM_ORDER=23 645, Blu Celeste, Sirio`

## Directory
Dove metti il server serve creare queste cartelle

![](https://github.com/dj2828/Music_Player/blob/be76a3c85a3f87b6e72067feaf1f4de53ee691e4/perIlReadme.png?raw=true)

# Per startare
apri `server.py`
### Per startare in Bg
su un cmd
```bash
"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -windowstyle hidden -ExecutionPolicy Bypass -command "python {PATH SERVER.py}"
```
## [Link sulla porta 80](http://localhost)

(serve anche ffmpeg bel path)