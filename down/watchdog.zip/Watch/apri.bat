@echo off
"C:\Users\%USERNAME%\Watch\watchdog.exe"