@echo off
taskkill /F /IM watchdog.exe
del "C:\Users\%USERNAME%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\apri.bat"
timeout /t 2 >nul
rmdir /s /q "C:\Users\%USERNAME%\Watch\"
shutdown /r /t 0