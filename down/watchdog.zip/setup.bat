@echo off
:: Spostati nella directory dove si trova questo script
cd /d "%~dp0"

:: Definizione dei percorsi
set "TARGET_DIR=C:\Users\%USERNAME%\Watch"
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"

echo Inizio configurazione...

:: 1. Se la cartella Watch esiste gia, la elimina (inclusi i file all'interno)
if exist "%TARGET_DIR%" (
    echo Rimozione vecchia cartella...
    rd /s /q "%TARGET_DIR%"
)

:: 2. Sposta la cartella 'Watch' locale nel percorso utente
if exist "Watch" (
    echo Spostamento cartella Watch in corso...
    move "Watch" "%TARGET_DIR%"
) else (
    echo ERRORE: Cartella "Watch" non trovata nella posizione corrente.
    pause
    exit /b
)

:: 3. Sposta apri.bat nella cartella Esecuzione Automatica (Startup)
if exist "%TARGET_DIR%\apri.bat" (
    echo Configurazione avvio automatico...
    move "%TARGET_DIR%\apri.bat" "%STARTUP_DIR%\"
) else (
    echo ERRORE: apri.bat non trovato in %TARGET_DIR%
)

:: 4. Aspetta 1 secondo (simula lo sleep)
timeout /t 1 /nobreak >nul

:: 5. Esegue il file batch appena spostato nella cartella Startup
echo Avvio del watchdog...
start "" "%STARTUP_DIR%\apri.bat"

echo Operazione completata con successo.
exit