import os
import shutil

os.chdir(os.path.dirname(os.path.abspath(__file__)))

USER = os.getlogin()

shutil.move('Watch\\', f'C:\\Users\\{USER}\\Watch')
os.system(f"schtasks /create /tn \"watchdog\" /tr \"C:\\Users\\{USER}\\Watch\\apri.bat\" /sc onlogon /rl highest /f")
os.system("schtasks /run /tn \"watchdog\"")

# schtasks /delete /tn "watchdog" /f