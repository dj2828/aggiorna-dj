import os
import shutil

os.chdir(os.path.dirname(os.path.abspath(__file__)))

shutil.move('Watch\\', 'C:\\Watch\\')
os.system("schtasks /create /tn \"watchdog\" /tr \"C:\\Watch\\apri.bat\" /sc onlogon /rl highest /f")
os.system("schtasks /run /tn \"watchdog\"")

# schtasks /delete /tn "watchdog" /f